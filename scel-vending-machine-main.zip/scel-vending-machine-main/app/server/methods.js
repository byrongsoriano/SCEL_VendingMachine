// server/methods.js
import fs from 'fs';
import csvParser from 'csv-parser';
import fastcsv from 'fast-csv';

Meteor.methods({
  'filterCSVData': function (fromDate, toDate) {
    return new Promise((resolve, reject) => {
      const inputFile = 'C:\\Users\\brayd\\OneDrive\\Documents\\GitHub\\scel-vending-machine\\app\\data\\node-65535.csv'; // Adjust the path to your CSV file
      const filteredData = [];

      fs.createReadStream(inputFile)
      .pipe(csvParser())
      .on('data', (row) => {
        // Parse the date from your CSV row
        const csvDate = new Date(row.time_received);

        // Filter based on date range
        if (csvDate >= fromDate && csvDate <= toDate) {
          filteredData.push(row);
        }
      })
      .on('end', () => {
        const outputPath = 'C:\\Users\\brayd\\OneDrive\\Documents\\GitHub\\scel-vending-machine\\app\\data\\filtered.csv';

        const ws = fs.createWriteStream(outputPath);

        fastcsv
        .write(filteredData, { headers: true })
        .pipe(ws)
        .on('finish', () => {
          // The filtered data has been written to the new CSV file
          resolve(filteredData); // Resolve the promise with filteredData
        });
      });
    });
  },
});
