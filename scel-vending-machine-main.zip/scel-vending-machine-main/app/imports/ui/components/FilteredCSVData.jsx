import React from 'react';
import PropTypes from 'prop-types';

const FilteredCSVData = ({ filteredData }) => {
  console.log('FilteredCSVData received data:', filteredData); // Add this line to check if data is received

  return (
    <div>
      <h2>Filtered Data</h2>
      <table>
        <thead>
        <tr>
          <th>apogee_w_m2</th>
          <th>batt_mv</th>
          <th>humidity_centi_pct</th>
          <th>node_addr</th>
          <th>panel_mv</th>
          <th>press_pa</th>
          <th>schema</th>
          <th>temp_c</th>
          <th>time_received</th>
          <th>uptime_ms</th>
        </tr>
        </thead>
        <tbody>
        {filteredData.map((row, index) => (
          <tr key={index}>
            <td>{row.apogee_w_m2}</td>
            <td>{row.batt_mv}</td>
            <td>{row.humidity_centi_pct}</td>
            <td>{row.node_addr}</td>
            <td>{row.panel_mv}</td>
            <td>{row.press_pa}</td>
            <td>{row.schema}</td>
            <td>{row.temp_c}</td>
            <td>{row.time_received}</td>
            <td>{row.uptime_ms}</td>
          </tr>
        ))}
        </tbody>
      </table>
    </div>
  );
};

FilteredCSVData.propTypes = {
  filteredData: PropTypes.arrayOf(
    PropTypes.shape({
      apogee_w_m2: PropTypes.number.isRequired,
      batt_mv: PropTypes.number.isRequired,
      humidity_centi_pct: PropTypes.number.isRequired,
      node_addr: PropTypes.number.isRequired,
      panel_mv: PropTypes.number.isRequired,
      press_pa: PropTypes.number.isRequired,
      schema: PropTypes.number.isRequired,
      temp_c: PropTypes.number.isRequired,
      time_received: PropTypes.string.isRequired,
      uptime_ms: PropTypes.number.isRequired,
    })
  ).isRequired,
};

export default FilteredCSVData;
