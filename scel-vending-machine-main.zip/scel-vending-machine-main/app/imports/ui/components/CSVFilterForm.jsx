import React, { Component } from 'react';
import { Meteor } from 'meteor/meteor';
import PropTypes from 'prop-types';

class CSVFilterForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fromDate: '',
      toDate: '',
      displayedValue: '',
    };
  }

  handleFromDateChange = (e) => {
    this.setState({ fromDate: e.target.value });
  };

  handleToDateChange = (e) => {
    this.setState({ toDate: e.target.value });
  };

  handleFilterData = () => {
    const { fromDate, toDate } = this.state;
    console.log('Button clicked, calling Meteor method...');
    Meteor.call('filterCSVData', new Date(fromDate), new Date(toDate), (error, result) => {
      if (error) {
        console.error('Error:', error);
      } else {
        console.log('Result received from Meteor method:');
        // Update the state with the result in the callback
        this.props.updateFilteredData(result);
      }
    });
  };

  render() {
    return (
      <div>
        <label>From Date:</label>
        <input type="date" value={this.state.fromDate} onChange={this.handleFromDateChange} />

        <label>To Date:</label>
        <input type="date" value={this.state.toDate} onChange={this.handleToDateChange} />

        <button onClick={this.handleFilterData}>Filter Data</button>
      </div>
    );
  }
}

CSVFilterForm.propTypes = {
  updateFilteredData: PropTypes.func.isRequired, // Ensure updateFilteredData is a required function prop
};

export default CSVFilterForm;
