import React, { useState } from 'react';
import { Container } from 'react-bootstrap';
import CSVFilterForm from '../components/CSVFilterForm';
import FilteredCSVData from '../components/FilteredCSVData';

const FilterDataPage = () => {
  const [filteredData, setFilteredData] = useState([]);

  const updateFilteredData = (data) => {
    setFilteredData(data);
    // console.log(data);
  };

  return (
    <Container>
      <h1>Filter CSV Data</h1>
      <CSVFilterForm updateFilteredData={updateFilteredData} />
      <FilteredCSVData filteredData={filteredData} />
    </Container>
  );
};
export default FilterDataPage;
